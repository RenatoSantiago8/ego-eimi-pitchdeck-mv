# Ego Eimi - Developer Challenge

MVP Gerador de Pitch Deck Appendix.